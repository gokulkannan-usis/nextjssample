

export default function joblistdata() {
    return (
        <div>
            <p>test</p>
          {/* {result.map((data: any, index: number) => (
            <div>
              <p key={index}>
                {data[1]}
                <span> close</span>
              </p>
            </div>
          ))} */}
        </div>
      );
}