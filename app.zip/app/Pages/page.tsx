"use client"
import { useRouter } from "next/navigation";
// import { useRouter } from "next/router";
// import { useRouter } from 'next/compat/router'

export default function Details() {
    // const router:any = useRouter();
    // const { search, location } = router.query || {};
    // console.log("test",router.query);

    return (
        <div>
            {/* <h1>About details: {search}</h1>
            <p>Location: {location}</p> */}
        </div>
    );
}

